// 每个dapp代表一个scope
export const scope = "demo";
